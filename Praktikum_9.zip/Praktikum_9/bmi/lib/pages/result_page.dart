// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'dart:math' as math;

const Color kNavy = Color(0xFF1B2A4A);

class ResultPage extends StatelessWidget {
  final String nama, gender, kategori;
  final double bmi, beratKg, tinggiCm;

  const ResultPage({
    required this.nama,
    required this.bmi,
    required this.gender,
    required this.kategori,
    required this.beratKg,
    required this.tinggiCm,
    super.key,
  });

  // ── Logika BMI ──────────────────────────────────────────

  String get _status {
    if (kategori == 'Dewasa') {
      if (bmi < 18.5) return 'Kurus';
      if (bmi < 23.0) return 'Normal';
      if (bmi < 25.0) return 'Berisiko';
      if (bmi < 30.0) return 'Obesitas I';
      return 'Obesitas II';
    } else if (kategori == 'Remaja') {
      if (bmi < 16.0) return 'Kurus';
      if (bmi < 22.0) return 'Normal';
      if (bmi < 27.0) return 'Gemuk';
      return 'Obesitas';
    } else {
      if (bmi < 14.0) return 'Kurus';
      if (bmi < 18.0) return 'Normal';
      if (bmi < 22.0) return 'Gemuk';
      return 'Obesitas';
    }
  }

  Color get _statusColor {
    switch (_status) {
      case 'Kurus':     return Colors.blue;
      case 'Normal':    return Colors.green;
      case 'Berisiko':
      case 'Gemuk':     return Colors.orange;
      default:          return Colors.red;
    }
  }

  // Posisi jarum gauge 0.0 - 1.0 (range BMI 10–40)
  double get _gaugeProgress => ((bmi - 10) / 30).clamp(0.0, 1.0);

  // Berat ideal
  double get _bmiMin => kategori == 'Dewasa' ? 18.5 : (kategori == 'Remaja' ? 16.0 : 14.0);
  double get _bmiMax => kategori == 'Dewasa' ? 22.9 : (kategori == 'Remaja' ? 21.9 : 17.9);
  double get _bmiTarget => kategori == 'Dewasa' ? 21.0 : (kategori == 'Remaja' ? 19.0 : 16.0);

  double _idealBerat(double bmiVal) {
    final t = tinggiCm / 100;
    return bmiVal * t * t;
  }

  // Saran berdasarkan status
  List<Map<String, dynamic>> get _saran {
    if (_status == 'Normal') {
      return [
        {'icon': Icons.restaurant_outlined,   'judul': 'Pola Makan',    'isi': 'Pertahankan asupan gizi seimbang dengan fokus pada protein dan serat.'},
        {'icon': Icons.directions_run_outlined,'judul': 'Aktivitas Fisik','isi': 'Lakukan jalan cepat atau jogging minimal 30 menit setiap hari.'},
        {'icon': Icons.bedtime_outlined,       'judul': 'Istirahat',     'isi': 'Tidur berkualitas 7-8 jam untuk membantu regulasi hormon lapar.'},
      ];
    } else if (_status == 'Kurus') {
      return [
        {'icon': Icons.restaurant_outlined,   'judul': 'Pola Makan',       'isi': 'Tingkatkan asupan kalori dengan makanan bergizi seperti kacang dan alpukat.'},
        {'icon': Icons.fitness_center_outlined,'judul': 'Latihan Kekuatan', 'isi': 'Lakukan latihan beban ringan untuk membangun massa otot.'},
        {'icon': Icons.local_hospital_outlined,'judul': 'Konsultasi',       'isi': 'Disarankan berkonsultasi dengan ahli gizi untuk program penambahan berat badan.'},
      ];
    } else {
      return [
        {'icon': Icons.no_food_outlined,        'judul': 'Kurangi Kalori',  'isi': 'Kurangi makanan tinggi gula dan lemak jenuh secara bertahap.'},
        {'icon': Icons.directions_walk_outlined, 'judul': 'Aktif Bergerak', 'isi': 'Mulai dengan berjalan kaki 30 menit setiap hari secara rutin.'},
        {'icon': Icons.local_hospital_outlined,  'judul': 'Konsultasi Medis','isi': 'Konsultasikan ke dokter untuk program penurunan berat badan yang aman.'},
      ];
    }
  }

  // ── Helper Widgets ───────────────────────────────────────

  // Dekorasi card yang sama dipakai berulang
  BoxDecoration get _cardDecor => BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      );

  // Badge kecil (gender & status)
  Widget _buildBadge({required Widget child, required Color borderColor, required Color bgColor}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderColor),
      ),
      child: child,
    );
  }

  // Item saran kesehatan
  Widget _buildSaranItem(Map<String, dynamic> saran) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Color(0xFFF0F2F5),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(saran['icon'] as IconData, size: 18, color: kNavy),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(saran['judul'] as String,
                    style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: kNavy)),
                SizedBox(height: 2),
                Text(saran['isi'] as String,
                    style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade600,
                        height: 1.4)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Build ────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF0F2F5),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              SizedBox(height: 16),

              // Top bar
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(children: [
                    Icon(Icons.monitor_heart_outlined, color: kNavy, size: 20),
                    SizedBox(width: 6),
                    Text('VITALITY BMI',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: kNavy,
                            letterSpacing: 1)),
                  ]),
                  Icon(Icons.share_outlined, color: kNavy, size: 22),
                ],
              ),

              SizedBox(height: 16),

              // Card profil
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(16),
                decoration: _cardDecor,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('PROFIL PENGGUNA',
                        style: TextStyle(
                            fontSize: 10,
                            letterSpacing: 1.2,
                            color: Colors.grey.shade500)),
                    SizedBox(height: 6),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(nama,
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: kNavy)),
                        Icon(Icons.person_outline, color: Colors.grey.shade400),
                      ],
                    ),
                    SizedBox(height: 8),
                    Row(
                      children: [
                        _buildBadge(
                          bgColor: Colors.grey.shade100,
                          borderColor: Colors.grey.shade300,
                          child: Row(children: [
                            Icon(gender == 'Pria' ? Icons.male : Icons.female,
                                size: 14, color: Colors.grey.shade600),
                            SizedBox(width: 4),
                            Text(gender,
                                style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey.shade600)),
                          ]),
                        ),
                        SizedBox(width: 8),
                        _buildBadge(
                          bgColor: _statusColor.withOpacity(0.1),
                          borderColor: _statusColor.withOpacity(0.3),
                          child: Row(children: [
                            Icon(Icons.verified_outlined,
                                size: 14, color: _statusColor),
                            SizedBox(width: 4),
                            Text(_status,
                                style: TextStyle(
                                    fontSize: 12,
                                    color: _statusColor,
                                    fontWeight: FontWeight.w500)),
                          ]),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              SizedBox(height: 12),

              // Card skor BMI + gauge
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(20),
                decoration: _cardDecor,
                child: Column(
                  children: [
                    Text('SKOR BMI ANDA',
                        style: TextStyle(
                            fontSize: 10,
                            letterSpacing: 1.2,
                            color: Colors.grey.shade500)),
                    SizedBox(height: 12),
                    SizedBox(
                      height: 160,
                      width: 240,
                      child: CustomPaint(
                        painter: _GaugePainter(
                          progress: _gaugeProgress,
                          color: _statusColor,
                        ),
                        child: Align(
                          alignment: Alignment(0, 0.6),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(bmi.toStringAsFixed(1),
                                  style: TextStyle(
                                      fontSize: 36,
                                      fontWeight: FontWeight.bold,
                                      color: kNavy)),
                              Text(_status.toUpperCase(),
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: _statusColor,
                                      letterSpacing: 1)),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 16),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: Container(
                        height: 8,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [
                            Colors.blue,
                            Colors.green,
                            Colors.yellow,
                            Colors.orange,
                            Colors.red,
                          ]),
                        ),
                      ),
                    ),
                    SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _barLabel('18.5', 'MIN'),
                        _barLabel('25.0', 'IDEAL'),
                        _barLabel('30.0', 'MAX'),
                      ],
                    ),
                  ],
                ),
              ),

              SizedBox(height: 12),

              // Card berat ideal
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(18),
                decoration: _cardDecor,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Icon(Icons.monitor_weight_outlined, color: kNavy, size: 20),
                      SizedBox(width: 8),
                      Text('Berat Badan Ideal',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: kNavy)),
                    ]),
                    SizedBox(height: 6),
                    RichText(
                      text: TextSpan(
                        style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                        children: [
                          TextSpan(text: 'Untuk tinggi '),
                          TextSpan(
                              text: '${tinggiCm.toInt()} cm',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, color: kNavy)),
                          TextSpan(text: ', rentang sehat Anda:'),
                        ],
                      ),
                    ),
                    SizedBox(height: 14),
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.symmetric(vertical: 16),
                      decoration: BoxDecoration(
                        color: Color(0xFFF0F2F5),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.grey.shade200),
                      ),
                      child: Column(children: [
                        Text(
                          '${_idealBerat(_bmiMin).toStringAsFixed(1)} kg  —  ${_idealBerat(_bmiMax).toStringAsFixed(1)} kg',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: kNavy),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Target optimal: ${_idealBerat(_bmiTarget).toStringAsFixed(1)} kg',
                          style: TextStyle(
                              fontSize: 12, color: Colors.grey.shade500),
                        ),
                      ]),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 12),

              // Card saran kesehatan
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(18),
                decoration: _cardDecor,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Saran Kesehatan',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: kNavy)),
                    SizedBox(height: 12),
                    ..._saran.map(_buildSaranItem).toList(),
                  ],
                ),
              ),

              SizedBox(height: 16),

              // Tombol hitung ulang
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: double.infinity,
                  height: 52,
                  decoration: BoxDecoration(
                    color: kNavy,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.refresh, color: Colors.white, size: 20),
                      SizedBox(width: 8),
                      Text('Hitung Ulang',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),

              SizedBox(height: 12),

              Text(
                'Hasil ini hanya sebagai referensi. Konsultasikan dengan tenaga medis profesional untuk evaluasi mendalam.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
              ),

              SizedBox(height: 12),

              Container(
                width: double.infinity,
                height: 70,
                decoration: BoxDecoration(
                  color: kNavy,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    'Sehat dimulai dari langkah kecil hari ini.',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w500),
                  ),
                ),
              ),

              SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _barLabel(String value, String label) {
    return Column(children: [
      Text(value,
          style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade700)),
      Text(label,
          style: TextStyle(fontSize: 9, color: Colors.grey.shade400)),
    ]);
  }
}

// Gauge setengah lingkaran
class _GaugePainter extends CustomPainter {
  final double progress;
  final Color color;

  _GaugePainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height * 0.85);
    final radius = size.width / 2 - 10;

    final bgPaint = Paint()
      ..color = Colors.grey.shade200
      ..style = PaintingStyle.stroke
      ..strokeWidth = 18
      ..strokeCap = StrokeCap.round;

    final fgPaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 18
      ..strokeCap = StrokeCap.round;

    // Arc background
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius),
        math.pi, math.pi, false, bgPaint);

    // Arc foreground sesuai progress
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius),
        math.pi, math.pi * progress, false, fgPaint);
  }

  @override
  bool shouldRepaint(_GaugePainter old) => old.progress != progress;
}