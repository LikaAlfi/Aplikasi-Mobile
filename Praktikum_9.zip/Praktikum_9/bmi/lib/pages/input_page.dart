// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'result_page.dart';

// Warna utama
const Color kNavy = Color(0xFF1B2A4A);

class InputPage extends StatefulWidget {
  const InputPage({super.key});

  @override
  State<InputPage> createState() => _InputPageState();
}

class _InputPageState extends State<InputPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _weightController = TextEditingController();
  final _heightController = TextEditingController();

  String _selectedGender = 'Pria';
  String? _selectedCategory;
  bool _showCategoryError = false;

  final List<String> _categories = ['Anak-anak', 'Remaja', 'Dewasa'];

  @override
  void dispose() {
    _nameController.dispose();
    _weightController.dispose();
    _heightController.dispose();
    super.dispose();
  }

  // Dekorasi field yang dipakai berulang
  InputDecoration _fieldDecor(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14),
      filled: true,
      fillColor: Colors.white,
      contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.shade200),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: kNavy),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.red.shade300),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.red.shade300),
      ),
    );
  }

  // Dekorasi card yang dipakai berulang
  BoxDecoration get _cardDecor => BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      );

  // Widget chip untuk gender & kategori
  Widget _buildChip({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
    IconData? icon,
    bool rounded = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: rounded ? 16 : 12,
          vertical: 11,
        ),
        decoration: BoxDecoration(
          color: isSelected ? Color(0xFFEEF1F8) : Colors.grey.shade100,
          borderRadius: BorderRadius.circular(rounded ? 20 : 10),
          border: Border.all(
            color: isSelected ? kNavy : Colors.grey.shade200,
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon,
                  size: 16,
                  color: isSelected ? kNavy : Colors.grey.shade400),
              SizedBox(width: 5),
            ],
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight:
                    isSelected ? FontWeight.w600 : FontWeight.normal,
                color: isSelected ? kNavy : Colors.grey.shade500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 16),

                // Top bar
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(children: [
                      Icon(Icons.monitor_heart_outlined,
                          color: kNavy, size: 20),
                      SizedBox(width: 6),
                      Text('VITALITY BMI',
                          style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: kNavy,
                              letterSpacing: 1)),
                    ]),
                    Icon(Icons.notifications_outlined,
                        color: kNavy, size: 22),
                  ],
                ),

                SizedBox(height: 28),

                // Judul
                Text('Hitung BMI Anda',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: kNavy)),
                SizedBox(height: 8),
                Text(
                  'Pantau kesehatan Anda dengan perhitungan\nIndeks Massa Tubuh yang akurat dan berbasis klinis.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 13,
                      color: Colors.grey.shade500,
                      height: 1.5),
                ),

                SizedBox(height: 24),

                // Card form utama
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(20),
                  decoration: _cardDecor,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      // Label helper
                      ..._buildLabel('Nama Lengkap'),
                      TextFormField(
                        controller: _nameController,
                        textCapitalization: TextCapitalization.words,
                        decoration: _fieldDecor('Masukkan nama Anda'),
                        validator: (v) => (v == null || v.isEmpty)
                            ? 'Mohon isi nama'
                            : null,
                      ),

                      SizedBox(height: 18),

                      ..._buildLabel('Jenis Kelamin'),
                      Row(
                        children: ['Pria', 'Wanita'].map((g) {
                          return Expanded(
                            child: Padding(
                              padding: EdgeInsets.only(
                                  right: g == 'Pria' ? 8 : 0),
                              child: _buildChip(
                                label: g,
                                isSelected: _selectedGender == g,
                                onTap: () =>
                                    setState(() => _selectedGender = g),
                                icon: g == 'Pria'
                                    ? Icons.male
                                    : Icons.female,
                              ),
                            ),
                          );
                        }).toList(),
                      ),

                      SizedBox(height: 18),

                      ..._buildLabel('Kategori Usia'),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: _categories.map((cat) {
                          return _buildChip(
                            label: cat,
                            isSelected: _selectedCategory == cat,
                            onTap: () => setState(() {
                              _selectedCategory = cat;
                              _showCategoryError = false;
                            }),
                            rounded: true,
                          );
                        }).toList(),
                      ),
                      if (_showCategoryError)
                        Padding(
                          padding: EdgeInsets.only(top: 6),
                          child: Text('Pilih kategori usia',
                              style: TextStyle(
                                  color: Colors.red.shade400,
                                  fontSize: 11)),
                        ),

                      SizedBox(height: 18),

                      // Berat & Tinggi 2 kolom
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ..._buildLabel('Berat Badan (kg)'),
                                TextFormField(
                                  controller: _weightController,
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                  decoration: _fieldDecor('0'),
                                  validator: (v) =>
                                      (v == null || v.isEmpty)
                                          ? 'Isi berat'
                                          : null,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ..._buildLabel('Tinggi Badan (cm)'),
                                TextFormField(
                                  controller: _heightController,
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                  decoration: _fieldDecor('0'),
                                  validator: (v) =>
                                      (v == null || v.isEmpty)
                                          ? 'Isi tinggi'
                                          : null,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: 24),

                      // Tombol hitung
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            _showCategoryError = _selectedCategory == null;
                          });
                          if (_formKey.currentState!.validate() &&
                              _selectedCategory != null) {
                            final berat =
                                double.parse(_weightController.text);
                            final tinggiCm =
                                double.parse(_heightController.text);
                            final tinggi = tinggiCm / 100;
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ResultPage(
                                  nama: _nameController.text,
                                  bmi: berat / (tinggi * tinggi),
                                  gender: _selectedGender,
                                  kategori: _selectedCategory!,
                                  beratKg: berat,
                                  tinggiCm: tinggiCm,
                                ),
                              ),
                            );
                          }
                        },
                        child: Container(
                          width: double.infinity,
                          height: 52,
                          decoration: BoxDecoration(
                            color: kNavy,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.calculate_outlined,
                                  color: Colors.white, size: 20),
                              SizedBox(width: 8),
                              Text('Hitung BMI',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 16),

                // Info card bawah
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Color(0xFFE8EBF2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.info_outline, color: kNavy, size: 20),
                      SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Mengapa BMI Penting?',
                                style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    color: kNavy)),
                            SizedBox(height: 4),
                            Text(
                              'Indeks Massa Tubuh membantu mengidentifikasi risiko kesehatan yang berkaitan dengan berat badan berlebih atau kurang secara klinis.',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey.shade600,
                                  height: 1.5),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Helper label supaya tidak perlu tulis SizedBox + Text berulang
  List<Widget> _buildLabel(String text) {
    return [
      Text(text,
          style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: kNavy)),
      SizedBox(height: 8),
    ];
  }
}