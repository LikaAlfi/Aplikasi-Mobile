// main.dart
import 'package:flutter/material.dart';
import 'pages/input_page.dart'; // ← pakai ini

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vitality BMI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFF0F2F5),
      ),
      home: const InputPage(),
    );
  }
}