import 'dart:convert';
import 'package:http/http.dart' as http;
import 'movie_model.dart';

class MovieService {
  static const String _apiKey = '678e254633688237036e91a1683c59d7';
  static const String _baseUrl = 'https://api.themoviedb.org/3';
  static const String imageBaseUrl = 'https://image.tmdb.org/t/p/w500';

  Future<List<MovieModel>> fetchPopularMovies() async {
    final uri = Uri.parse(
      '$_baseUrl/movie/popular?api_key=$_apiKey&language=id-ID',
    );

    final response = await http.get(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    ).timeout(
      const Duration(seconds: 10),
      onTimeout: () =>
          throw Exception('Request timeout. Periksa koneksi internet kamu.'),
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);
      final List<dynamic> results = data['results'];
      return results.map((json) => MovieModel.fromJson(json)).toList();
    } else if (response.statusCode == 401) {
      throw Exception('API Key tidak valid.');
    } else {
      throw Exception('Gagal memuat film. Status: ${response.statusCode}');
    }
  }

  Future<List<MovieModel>> searchMovies(String query) async {
    final uri = Uri.parse(
      '$_baseUrl/search/movie?api_key=$_apiKey&language=id-ID&query=$query',
    );

    final response = await http.get(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    ).timeout(
      const Duration(seconds: 10),
      onTimeout: () =>
          throw Exception('Request timeout. Periksa koneksi internet kamu.'),
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);
      final List<dynamic> results = data['results'];
      return results.map((json) => MovieModel.fromJson(json)).toList();
    } else {
      throw Exception('Gagal mencari film. Status: ${response.statusCode}');
    }
  }
}